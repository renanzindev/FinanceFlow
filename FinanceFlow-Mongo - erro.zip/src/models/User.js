import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  full_name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
  },
  profile_picture: {
    type: String,
    default: '',
  },
  currency: {
    type: String,
    default: 'BRL',
  },
  dateFormat: {
    type: String,
    default: 'dd/MM/yyyy',
  },
  // Adicione aqui outros campos que possam ser necessários para autenticação/gerenciamento de usuário
  // Por exemplo, password (hashed), roles, etc.
  // Este projeto parece usar um provedor de autenticação externo (base44.auth),
  // então a gestão de senhas pode não ser necessária aqui diretamente.
  // Vamos manter simples por enquanto e focar nos dados do perfil.
  external_auth_id: { // Para vincular ao ID do provedor de autenticação externo
    type: String,
    unique: true,
    sparse: true, // Permite múltiplos documentos com valor null, mas único se não for null
  }
}, { timestamps: true });

// Método para simular o 'User.me()' e 'User.updateMyUserData()' do base44.auth
// Estes seriam implementados de forma mais robusta em uma aplicação real,
// possivelmente em um arquivo de serviço/controller separado.

// Exemplo estático (simulado, pois não temos o contexto de autenticação real aqui)
userSchema.statics.me = async function (externalId) {
  // Em um cenário real, você obteria o ID do usuário autenticado (ex: de um token JWT)
  // e buscaria o usuário correspondente no banco de dados.
  // Por agora, vamos assumir que um externalId é passado para simulação.
  if (!externalId) {
    // Tenta encontrar um usuário qualquer se nenhum ID for fornecido (para fins de exemplo)
    // Em um app real, isso seria um erro ou retornaria null se não autenticado.
    console.warn('Tentando buscar usuário sem externalId. Isso é apenas para simulação.');
    return this.findOne(); 
  }
  return this.findOne({ external_auth_id: externalId });
};

userSchema.statics.updateMyUserData = async function (externalId, data) {
  // Similar ao 'me', o externalId viria do contexto de autenticação.
  if (!externalId) {
    throw new Error('Usuário não autenticado ou ID externo não fornecido.');
  }
  return this.findOneAndUpdate({ external_auth_id: externalId }, data, { new: true });
};


const User = mongoose.model('User', userSchema);

export default User;
